﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace LibraryManagementSystem.Librarian.ApplicationLayer.UserControls
{
    public partial class Login : System.Web.UI.UserControl
    {
        string strcon = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        
        protected void Page_Load(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(strcon);
            if (con.State ==ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            int i = 0;
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from librarianregister where username='" + txtuserName.Text + "' and password='" + txtpassword.Text + "'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            i = Convert.ToInt32(dt.Rows.Count.ToString());
            con.Close();
            if(i>0)
            {
                Response.Redirect("Home.aspx");
            }
            else
            {
                error.Style.Add("display", "block");
            }
        }
    }
}