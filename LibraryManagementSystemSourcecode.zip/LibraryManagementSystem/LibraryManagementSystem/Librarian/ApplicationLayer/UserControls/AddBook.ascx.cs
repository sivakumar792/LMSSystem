﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem.Librarian.ApplicationLayer.UserControls
{
    public partial class AddBook : System.Web.UI.UserControl
    {
        string strcon = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
        }

       

        protected void btnsave_Click(object sender, EventArgs e)
        {
            string path = "";
            FileUpload1.SaveAs(Request.PhysicalApplicationPath + "/Librarian/booksimages/" + FileUpload1.FileName.ToString());
            path = "booksimages/" + FileUpload1.FileName.ToString();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into books values('" + txtbooktitle.Text + "','" + path.ToString() + "','" + txtbookauthor.Text + "','" + txtbookpublisher.Text + "','" + 1 + "')";
            cmd.ExecuteNonQuery();
            msg.Style.Add("display", "block");
            Response.Redirect("BookList.aspx");
        }
    }
}