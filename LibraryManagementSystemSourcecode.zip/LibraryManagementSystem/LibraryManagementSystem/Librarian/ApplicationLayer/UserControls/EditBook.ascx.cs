﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LibraryManagementSystem.Librarian.ApplicationLayer.UserControls
{
    public partial class EditBook : System.Web.UI.UserControl
    {
        string strcon = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        int id;
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(strcon);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();

            id = Convert.ToInt32(Request.QueryString["ID"].ToString());

            
            
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = " select * from books where ID="+id+"";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dt);
            foreach(DataRow dr in dt.Rows)
            {
                txtbooktitle.Text = dr["BookTitle"].ToString();
                txtbookauthor.Text= dr["BookAuthor"].ToString();
                txtbookpublisher.Text = dr["BookPublisher"].ToString();
                bookimg.Text= dr["BookImage"].ToString();

            }
        }

        protected void btnsave_Click(object sender, EventArgs e)
        {
            string bookimagename = "";
            if(FileUpload1.FileName.ToString() =="")
            {
                bookimagename = bookimg.Text;
                SqlConnection conn = new SqlConnection(strcon);
                conn.Open();
                SqlCommand commd = conn.CreateCommand();
                commd.CommandType = CommandType.Text;
                commd.CommandText = "update books set BookTitle='" + txtbooktitle.Text + "',BookImage='" + bookimagename + "',BookAuthor ='" + txtbookauthor.Text + "',BookPublisher='" + txtbookpublisher.Text + "',BookUserID='" + 1 + "'";
                commd.ExecuteNonQuery();

                Response.Redirect("BookList.aspx");
            }
            else { 
            string path = "";
            FileUpload1.SaveAs(Request.PhysicalApplicationPath + "/Librarian/booksimages/" + FileUpload1.FileName.ToString());
            path = "booksimages/" + FileUpload1.FileName.ToString();
            SqlConnection con = new SqlConnection(strcon);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update books set BookTitle='"+txtbooktitle.Text+"',BookImage='"+path.ToString()+"',BookAuthor ='"+txtbookauthor.Text+"',BookPublisher='"+txtbookpublisher.Text+"',BookUserID='"+1+"'";
            cmd.ExecuteNonQuery();
            
            Response.Redirect("BookList.aspx");
            }
        }
    }
}